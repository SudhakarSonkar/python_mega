import functions
import FreeSimpleGUI as sg

label = sg.Text("Type in a to-do")
input_box = sg.InputText(tooltip="Enter to-do", key='todo')
add_button = sg.Button("Add")
list_box = sg.Listbox(values=functions.get_todos(), key='todos', enable_events=True, size=[45, 10])
edit_button = sg.Button("Edit")

layout = [[label], [input_box, add_button], [list_box, edit_button]]
window = sg.Window('My To-Do App', 
                   layout=layout,
                   font=("Helvetica", 20))

while True:
    event, values = window.read()
    print(event, values)
    match event:
        case "Add":
            todo = functions.get_todos()
            todo.append(values['todo'] + '\n')
            functions.write_todos(todo)
            window['todos'].update(values=todo)
        
        case "Edit":
            try:
                todo_to_edit = values['todos'][0]
                new_todo = values['todo']
                todos = functions.get_todos()
                index = todos.index(todo_to_edit)
                todos[index] = new_todo + '\n'
                functions.write_todos(todos)
                window['todos'].update(values=todos)
            except IndexError:
                sg.popup("Please select a to-do item first.")
        
        case 'todos':
            window['todo'].update(value=values['todos'][0].strip())
        
        case sg.WIN_CLOSED:
            break    
        
window.close()
